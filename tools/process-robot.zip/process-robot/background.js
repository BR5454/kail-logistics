chrome.action.onClicked.addListener(async function (tab) {
  try {
    await chrome.tabs.sendMessage(tab.id, { q: 'toggle' });
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      setTimeout(function () { chrome.tabs.sendMessage(tab.id, { q: 'toggle' }).catch(function () {}); }, 300);
    } catch (e2) { /* chrome:// pages etc. */ }
  }
});
chrome.runtime.onMessage.addListener(function (m, sender, reply) {
  if (m && m.q === 'tabId') { reply(sender.tab ? sender.tab.id : null); }
});
