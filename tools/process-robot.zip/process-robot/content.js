(function () {
'use strict';
if (window.__kailRobot) return;
window.__kailRobot = true;

var KEY = 'pr_state_v1';
var S = null, myTab = null, recGrab = null, running = false, unloading = false, minimized = false;
var toastMsg = null, toastT = 0;

function fresh() {
  return { openTab: null, tab: 'teach', rec: false, recTab: null, startUrl: '', useStart: true, steps: [], seq: 0,
    inputsText: '', delay: 2, timeout: 20, urlTpl: '', useUrl: false,
    run: { active: false, paused: false, manual: false, tab: null, idx: 0, step: 0, cur: {}, rows: null, err: '' },
    results: [], tableHdr: [] };
}
function load() {
  return new Promise(function (res) {
    chrome.storage.local.get(KEY, function (o) {
      var s = o && o[KEY];
      var f = fresh();
      if (s) { for (var k in f) if (!(k in s)) s[k] = f[k]; } else s = f;
      S = s; res(s);
    });
  });
}
function save() { return new Promise(function (res) { var o = {}; o[KEY] = S; chrome.storage.local.set(o, function () { res(); }); }); }
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function clean(t) { return (t || '').replace(/\s+/g, ' ').trim(); }
window.addEventListener('beforeunload', function () { unloading = true; });
window.addEventListener('pagehide', function () { unloading = true; });

/* ================= locators ================= */
function stableId(id) { return id && id.length < 60 && !/\d{4,}|[a-f0-9]{10,}|^:r|^ember|^ext-gen|^react-select/i.test(id); }
function cssPath(el) {
  var parts = [];
  while (el && el.nodeType === 1 && el !== document.body && el !== document.documentElement) {
    var tag = el.tagName.toLowerCase(), i = 1, s = el;
    while ((s = s.previousElementSibling)) if (s.tagName === el.tagName) i++;
    parts.unshift((tag.indexOf(':') > -1 ? '*' : tag) + ':nth-of-type(' + i + ')');
    el = el.parentElement;
  }
  return 'body > ' + parts.join(' > ');
}
function makeLoc(el, withText) {
  var loc = { tag: el.tagName, path: cssPath(el) };
  if (stableId(el.id)) loc.id = el.id;
  var n = el.getAttribute('name'); if (n) loc.name = n;
  var a = el.getAttribute('aria-label'); if (a) loc.aria = a;
  var p = el.getAttribute('placeholder'); if (p) loc.ph = p;
  if (withText) { var t = clean(el.innerText || el.value || ''); if (t && t.length <= 40) loc.text = t; }
  return loc;
}
function attrSel(k, v) { return '[' + k + '="' + String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]'; }
function visible(el) { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); }
function qsa(sel) { try { return Array.prototype.slice.call(document.querySelectorAll(sel)); } catch (e) { return []; } }
function pick(list, loc) {
  list = list.filter(function (e) { return e.tagName === loc.tag; });
  if (!list.length) return null;
  var byPath = null; try { byPath = document.querySelector(loc.path); } catch (e) {}
  if (byPath && list.indexOf(byPath) > -1) return byPath;
  var v = list.filter(visible);
  return v[0] || list[0];
}
function escRe(x) { return x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function labelOf(t) {
  t = clean(t); var m = t.match(/^([A-Za-z][A-Za-z .#()\/&_-]{1,40}?)\s*[:\uff1a]/);
  return m ? m[1].trim() : null;
}
function staticOf(t) { t = clean(t); return t && t.length <= 25 && !/\d/.test(t) ? t : null; }
function nthPath(base, el) {
  var parts = [], cur = el;
  while (cur && cur !== base) {
    var i = 1, s = cur; while ((s = s.previousElementSibling)) if (s.tagName === cur.tagName) i++;
    parts.unshift(cur.tagName.toLowerCase() + ':nth-of-type(' + i + ')'); cur = cur.parentElement;
  }
  return cur ? (parts.length ? ':scope > ' + parts.join(' > ') : '') : null;
}
function anchorsFor(el) {
  var out = [], L = labelOf(el.innerText);
  if (L) out.push({ k: 'self', label: L });
  var base = el;
  for (var up = 0; up < 4 && base && base !== document.body; up++) {
    ['next', 'prev'].forEach(function (dir) {
      var sib = base[dir + 'ElementSibling'];
      if (!sib || out.length >= 4) return;
      var lab = labelOf(sib.innerText), ex = false;
      if (!lab) { lab = staticOf(sib.innerText); ex = !!lab; }
      if (lab) out.push({ k: dir, label: lab, exact: ex, baseTag: base.tagName, rel: up ? nthPath(base, el) : '' });
    });
    base = base.parentElement;
  }
  return out;
}
function labelMatch(text, a) {
  text = clean(text);
  return a.exact ? text === a.label : new RegExp('^' + escRe(a.label) + '\\s*[:\uff1a]').test(text);
}
function anchorCands(a) {
  var all = document.body ? document.body.querySelectorAll('*') : [], hits = [];
  for (var i = 0; i < all.length; i++) {
    var e = all[i];
    if (/^(SCRIPT|STYLE|NOSCRIPT)$/.test(e.tagName)) continue;
    if (labelMatch(e.textContent, a)) hits.push(e);
  }
  return hits.filter(function (e) { return !hits.some(function (o) { return o !== e && e.contains(o); }); });
}
function byAnchor(a) {
  var cands = anchorCands(a);
  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    if (a.k === 'self') return c;
    var cur = c;
    for (var j = 0; j < 6 && cur && cur !== document.body; j++) {
      var b = a.k === 'next' ? cur.previousElementSibling : cur.nextElementSibling;
      if (b && b.tagName === a.baseTag) {
        var t = null; try { t = a.rel ? b.querySelector(a.rel) : b; } catch (x) {}
        if (t) return t;
      }
      cur = cur.parentElement;
    }
  }
  return null;
}
function stripLabel(v, loc) {
  var a = (loc && loc.anchors || []).filter(function (x) { return x.k === 'self'; })[0];
  if (!a) return v;
  return v.replace(new RegExp('^' + escRe(a.label) + '\\s*[:\uff1a]\\s*'), '');
}
function locate(loc) {
  var e;
  if (loc.anchors) for (var ai = 0; ai < loc.anchors.length; ai++) { e = byAnchor(loc.anchors[ai]); if (e) return e; }
  if (loc.id) { e = document.getElementById(loc.id); if (e && e.tagName === loc.tag) return e; }
  if (loc.name && (e = pick(qsa(attrSel('name', loc.name)), loc))) return e;
  if (loc.aria && (e = pick(qsa(attrSel('aria-label', loc.aria)), loc))) return e;
  if (loc.ph && (e = pick(qsa(attrSel('placeholder', loc.ph)), loc))) return e;
  if (loc.text) {
    var m = qsa(loc.tag.toLowerCase()).filter(function (x) { return clean(x.innerText || x.value || '') === loc.text; });
    if ((e = pick(m, loc))) return e;
  }
  try { e = document.querySelector(loc.path); } catch (x) { e = null; }
  return e;
}
async function findEl(loc, needText) {
  var t0 = Date.now(), last = null, lim = (S.timeout || 20) * 1000;
  while (Date.now() - t0 < lim) {
    if (unloading || !S.run.active) return null;
    var e = locate(loc);
    if (e) { last = e; if (visible(e) && (!needText || readVal(e))) return e; }
    await sleep(300);
  }
  return last;
}
function readVal(el) {
  if (!el) return '';
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return clean(el.value);
  return clean(el.innerText || el.textContent);
}

/* ================= replay actions ================= */
function fireMouse(el, t) {
  var C = /^pointer/.test(t) && window.PointerEvent ? PointerEvent : MouseEvent;
  el.dispatchEvent(new C(t, { bubbles: true, cancelable: true, composed: true, view: window, button: 0 }));
}
function doClick(el) {
  try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
  var a = el.closest('a[href]');
  if (a && a.target === '_blank' && !/^javascript:/i.test(a.getAttribute('href'))) { location.assign(a.href); return; }
  ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (t) { fireMouse(el, t); });
  el.click();
}
function setValue(el, v) {
  try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
  el.focus();
  if (el.isContentEditable) { el.textContent = v; }
  else {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var d = Object.getOwnPropertyDescriptor(proto, 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
  }
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}
function pressEnter(el) {
  el.focus();
  var prevented = false;
  ['keydown', 'keypress', 'keyup'].forEach(function (t) {
    var ev = new KeyboardEvent(t, { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true });
    try { Object.defineProperty(ev, 'keyCode', { get: function () { return 13; } }); Object.defineProperty(ev, 'which', { get: function () { return 13; } }); } catch (e) {}
    el.dispatchEvent(ev);
    if (t === 'keydown' && ev.defaultPrevented) prevented = true;
  });
  if (!prevented && el.form) { try { el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit(); } catch (e) {} }
}
function setSelect(el, s) {
  var opts = Array.prototype.slice.call(el.options || []);
  var o = opts.filter(function (x) { return x.value === s.val; })[0] || opts.filter(function (x) { return clean(x.text) === s.text; })[0];
  if (o) el.value = o.value;
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}
function grabTable(t) {
  var trs = Array.prototype.slice.call(t.querySelectorAll('tr')).filter(function (r) { return r.closest('table') === t; });
  var hr = t.querySelector('thead tr') || trs.filter(function (r) { return !r.querySelector('td'); })[0];
  var hdr = hr ? Array.prototype.map.call(hr.children, function (c) { return clean(c.innerText); }) : [];
  var rows = trs.filter(function (r) { return r.querySelector('td'); }).map(function (r) {
    return Array.prototype.map.call(r.children, function (c) { return clean(c.innerText); });
  });
  return { hdr: hdr, rows: rows };
}

/* ================= runner ================= */
function parseInputs() {
  var list = rawInputs();
  if (S.uniq === false) return list;
  var seen = {};
  return list.filter(function (r) { var k = r.join('\t').toUpperCase(); if (seen[k]) return false; seen[k] = 1; return true; });
}
function rawInputs() {
  return (S.inputsText || '').split(/\r?\n/).map(function (l) { return l.replace(/\s+$/, ''); })
    .filter(function (l) { return l.trim(); }).map(function (l) { return l.split('\t').map(function (x) { return x.trim(); }); });
}
function plan() {
  if (S.useUrl && S.urlTpl) {
    return [{ t: 'goto', tpl: S.urlTpl }].concat(S.steps.filter(function (x) { return /^(grab|table|wait|pause)$/.test(x.t); }));
  }
  var p = [];
  if (S.useStart && S.startUrl) p.push({ t: 'goto', url: S.startUrl });
  return p.concat(S.steps);
}
function fillTpl(tpl, inp) { return tpl.replace(/\{(\d)\}/g, function (m, d) { return encodeURIComponent(inp[parseInt(d, 10) - 1] || ''); }); }
function detectTpl() {
  var t = S.steps.filter(function (x) { return x.t === 'type' && x.src === 'col1' && x.val; })[0];
  if (!t) return;
  var smp = String(t.val).trim(), href = location.href;
  if (smp.length >= 4 && href.indexOf(smp) > -1) { S.urlTpl = href.split(smp).join('{1}'); S.useUrl = true; }
}
function inputFor(s, inp) {
  if (!s.src || s.src === 'fixed') return s.val || '';
  var k = parseInt(s.src.replace('col', ''), 10) - 1;
  return inp[k] || '';
}
async function finishEntry(inp) {
  var r = S.run;
  if (r.rows && r.rows.length) r.rows.forEach(function (row) { S.results.push({ in: inp, v: r.cur, t: row, err: r.err }); });
  else S.results.push({ in: inp, v: r.cur, t: null, err: r.err });
  r.idx++; r.step = 0; r.cur = {}; r.rows = null; r.err = '';
  await save();
}
async function runLoop() {
  if (running) return;
  running = true; render();
  try {
    while (S.run.active && !S.run.paused && !unloading) {
      var inputs = parseInputs(), r = S.run;
      if (r.idx >= inputs.length) { r.active = false; await save(); toast('Kaam poora! ' + S.results.length + ' rows. "Result" tab se download karo.'); S.tab = 'result'; break; }
      var inp = inputs[r.idx], P = plan();
      if (r.step >= P.length) { await finishEntry(inp); render(); await sleep(300); continue; }
      var s = P[r.step]; render();
      if (s.t === 'goto') {
        var gu = s.tpl ? fillTpl(s.tpl, inp) : s.url;
        r.step++; await save(); unloading = true;
        if (gu === location.href) location.reload(); else location.assign(gu);
        return;
      }
      if (s.t === 'wait') { await sleep((s.sec || 2) * 1000); r.step++; await save(); continue; }
      if (s.t === 'pause') { r.paused = true; r.manual = true; r.step++; await save(); toast('Ab aap khud karo (captcha/OTP), phir "Continue" dabao'); break; }
      var needText = s.t === 'grab';
      var el = await findEl(s.loc, needText);
      if (unloading || !S.run.active) return;
      if (!el) {
        r.err = 'Step ' + (S.steps.indexOf(s) + 1) + ' (' + desc(s) + ') nahi mila';
        if (s.t === 'grab') { r.cur[s.id] = ''; r.step++; await save(); continue; }
        await finishEntry(inp); toast('Entry ' + r.idx + ': ' + 'element nahi mila, agli entry pe ja raha hun'); continue;
      }
      if (s.t === 'grab') {
        var v = readVal(el), tS = Date.now();
        while (Date.now() - tS < 4000 && !unloading) { await sleep(600); var v2 = readVal(locate(s.loc)); if (v2 === v) break; v = v2; }
        r.cur[s.id] = stripLabel(v, s.loc); r.step++; await save(); continue;
      }
      if (s.t === 'table') {
        var g = grabTable(el), t0 = Date.now();
        while (!g.rows.length && Date.now() - t0 < 8000 && !unloading) { await sleep(400); g = grabTable(el); }
        r.rows = g.rows; if (g.hdr.length) S.tableHdr = g.hdr; r.step++; await save(); continue;
      }
      r.step++; await save();
      if (s.t === 'type') { setValue(el, inputFor(s, inp)); await sleep(400); }
      else if (s.t === 'select') { setSelect(el, s); await sleep(600); }
      else if (s.t === 'enter') { pressEnter(el); await sleep((S.delay || 2) * 1000); }
      else if (s.t === 'click') { doClick(el); await sleep((S.delay || 2) * 1000); }
    }
  } catch (e) { toast('Error: ' + e.message); }
  finally { running = false; if (!unloading) render(); }
}

/* ================= recording ================= */
function isOurs(e) { return e.target === host; }
function isTypeable(el) {
  if (el.isContentEditable) return true;
  if (el.tagName === 'TEXTAREA') return true;
  if (el.tagName !== 'INPUT') return false;
  return !/^(button|submit|reset|checkbox|radio|file|image|range|color)$/i.test(el.type);
}
function recording() { return S && S.rec && S.recTab === myTab; }
function sameLoc(a, b) { return a && b && a.path === b.path && a.tag === b.tag; }
function pushStep(s) { s.id = 's' + (++S.seq); S.steps.push(s); save(); render(); }
function upsertType(el) {
  var loc = makeLoc(el, false), v = el.isContentEditable ? clean(el.textContent) : el.value;
  var L = S.steps, last = L[L.length - 1], prev = L[L.length - 2];
  if (last && last.t === 'type' && sameLoc(last.loc, loc)) { last.val = v; save(); render(); return; }
  if (last && last.t === 'enter' && prev && prev.t === 'type' && sameLoc(prev.loc, loc)) { prev.val = v; save(); render(); return; }
  var hasCol = L.some(function (x) { return x.t === 'type' && x.src && x.src !== 'fixed'; });
  pushStep({ t: 'type', loc: loc, val: v, src: hasCol ? 'fixed' : 'col1' });
}
function onClickCap(e) {
  if (!S || !e.isTrusted || isOurs(e)) return;
  if (recGrab) {
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    var el = e.target;
    if (recGrab === 'table') {
      var t = el.closest('table'); if (!t) { toast('Ye table nahi h - table ke andar click karo'); return; }
      pushStep({ t: 'table', loc: makeLoc(t, false) }); recGrab = null; clearHi();
      var g = grabTable(t); toast('Table step jud gaya (' + g.rows.length + ' rows abhi dikh rahi)'); return;
    }
    var n = S.steps.filter(function (x) { return x.t === 'grab'; }).length + 1;
    var gl = makeLoc(el, false); gl.anchors = anchorsFor(el);
    var selfA = gl.anchors.filter(function (x) { return x.k === 'self'; })[0];
    pushStep({ t: 'grab', loc: gl, name: selfA ? selfA.label : guessName(el, n), sample: stripLabel(readVal(el), gl).slice(0, 60) });
    toast('Field jud gaya: "' + readVal(el).slice(0, 30) + '" - aur field pe click karo ya "Done" dabao');
    return;
  }
  if (!recording()) return;
  var el2 = e.target;
  if (!el2 || el2.nodeType !== 1 || isTypeable(el2) || el2.closest('select,option')) return;
  var c = el2.closest('a,button,[role="button"],[role="tab"],[role="menuitem"],[role="option"],[role="link"],input[type="submit"],input[type="button"],input[type="checkbox"],input[type="radio"],label,summary') || el2;
  pushStep({ t: 'click', loc: makeLoc(c, true) });
  var a = c.closest('a[href]');
  if (a && a.target === '_blank' && !/^javascript:/i.test(a.getAttribute('href'))) { e.preventDefault(); location.assign(a.href); }
}
function blockCap(e) { if (recGrab && e.isTrusted && !isOurs(e)) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); } }
function onChangeCap(e) {
  if (!recording() || !e.isTrusted || isOurs(e)) return;
  var el = e.target;
  if (el.tagName === 'SELECT') { var o = el.options[el.selectedIndex]; pushStep({ t: 'select', loc: makeLoc(el, false), val: el.value, text: o ? clean(o.text) : '' }); return; }
  if (isTypeable(el)) upsertType(el);
}
function onKeyCap(e) {
  if (e.key === 'Escape' && recGrab) { recGrab = null; clearHi(); render(); return; }
  if (!recording() || !e.isTrusted || isOurs(e)) return;
  if (e.key === 'Enter' && isTypeable(e.target) && e.target.tagName !== 'TEXTAREA') {
    upsertType(e.target);
    pushStep({ t: 'enter', loc: makeLoc(e.target, false) });
  }
}
function guessName(el, n) {
  var own = clean(el.innerText || '');
  if (own.length > 25 && own.split(',').length >= 3) return 'Address';
  if (/^\+?\d[\d\s-]{8,14}$/.test(own)) return 'Mobile';
  var p = el.previousElementSibling, t;
  if (p) { t = clean(p.innerText); if (t && t.length < 35 && (/[:：]$/.test(t) || !/\d/.test(t))) return t.replace(/[:：\-]+$/, '').trim(); }
  var cell = el.closest('td'); if (cell && cell.previousElementSibling) { t = clean(cell.previousElementSibling.innerText); if (t && t.length < 35) return t.replace(/[:：\-]+$/, '').trim(); }
  return 'Field ' + n;
}

/* hover highlight in grab mode */
var hiBox = null;
function clearHi() { if (hiBox) hiBox.style.display = 'none'; }
function onMove(e) {
  if (!recGrab || isOurs(e)) { clearHi(); return; }
  var el = recGrab === 'table' ? (e.target.closest('table') || e.target) : e.target;
  var r = el.getBoundingClientRect();
  hiBox.style.display = 'block'; hiBox.style.left = r.left + 'px'; hiBox.style.top = r.top + 'px'; hiBox.style.width = r.width + 'px'; hiBox.style.height = r.height + 'px';
}

/* ================= UI ================= */
var host = document.createElement('div');
host.setAttribute('data-process-robot', '1');
host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
var root = host.attachShadow({ mode: 'open' });
function h(tag, props, kids) {
  var e = document.createElement(tag);
  if (props) for (var k in props) {
    if (k === 'on') { for (var ev in props.on) e.addEventListener(ev, props.on[ev]); }
    else if (k === 'text') e.textContent = props[k];
    else if (k === 'cls') e.className = props[k];
    else if (props[k] !== false && props[k] != null) e.setAttribute(k, props[k] === true ? '' : props[k]);
  }
  (kids || []).forEach(function (c) { if (c == null || c === false) return; e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
  return e;
}
var style = h('style');
style.textContent = [
'*{box-sizing:border-box;font-family:Segoe UI,Roboto,Arial,sans-serif;}',
'.p{position:fixed;right:16px;bottom:16px;width:410px;max-height:85vh;display:flex;flex-direction:column;background:#fff;color:#1f2328;border:1px solid #c9ced6;border-radius:12px;box-shadow:0 10px 32px rgba(0,0,0,.3);font-size:13px;overflow:hidden;}',
'.hd{background:#3b1f7a;color:#fff;padding:9px 12px;display:flex;align-items:center;gap:8px;cursor:move;user-select:none;}',
'.hd b{flex:1;font-size:14px;}',
'.hd button{background:rgba(255,255,255,.2);color:#fff;border:0;border-radius:6px;width:26px;height:24px;cursor:pointer;}',
'.tabs{display:flex;border-bottom:1px solid #d8dee4;}',
'.tabs button{flex:1;border:0;background:#f6f8fa;padding:8px 4px;cursor:pointer;font-size:12.5px;border-bottom:3px solid transparent;}',
'.tabs button.on{background:#fff;border-bottom-color:#6f42c1;font-weight:600;}',
'.bd{padding:10px 12px;overflow:auto;display:flex;flex-direction:column;gap:8px;}',
'.row{display:flex;gap:6px;flex-wrap:wrap;align-items:center;}',
'.btn{border:1px solid #c9ced6;background:#f6f8fa;color:#1f2328;border-radius:7px;padding:6px 10px;cursor:pointer;font-size:12.5px;}',
'.btn:hover{filter:brightness(.96);}',
'.btn.pri{background:#6f42c1;border-color:#6f42c1;color:#fff;}',
'.btn.go{background:#1a7f37;border-color:#1a7f37;color:#fff;font-weight:600;font-size:14px;padding:8px 14px;}',
'.btn.rec{background:#cf222e;border-color:#cf222e;color:#fff;}',
'.btn.on{background:#fb8500;border-color:#fb8500;color:#fff;}',
'.btn.red{color:#cf222e;}',
'.ban{border-radius:7px;padding:7px 9px;font-size:12.5px;line-height:1.4;}',
'.ban.r{background:#ffebe9;border:1px solid #ffcecb;}',
'.ban.b{background:#f0f6ff;border:1px solid #c8dcf5;}',
'.ban.y{background:#fff8c5;border:1px solid #eedc82;}',
'.steps{display:flex;flex-direction:column;gap:4px;max-height:260px;overflow:auto;}',
'.st{display:flex;gap:6px;align-items:center;border:1px solid #e1e4e8;border-radius:7px;padding:5px 7px;font-size:12px;}',
'.st .n{background:#6f42c1;color:#fff;border-radius:10px;min-width:20px;text-align:center;font-size:11px;padding:1px 5px;}',
'.st .d{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
'.st .x,.st .e{cursor:pointer;color:#57606a;padding:0 3px;}',
'.st .x:hover{color:#cf222e;}.st .e:hover{color:#0969da;}',
'select,input.n{border:1px solid #c9ced6;border-radius:6px;padding:3px 4px;font-size:12px;}',
'input.n{width:54px;}',
'textarea{width:100%;height:140px;border:1px solid #c9ced6;border-radius:7px;padding:6px;font-family:Consolas,monospace;font-size:12.5px;resize:vertical;}',
'.tw{overflow:auto;max-height:240px;border:1px solid #d8dee4;border-radius:7px;}',
'table{border-collapse:collapse;width:max-content;min-width:100%;font-size:12px;}',
'th,td{border-bottom:1px solid #eaeef2;padding:4px 7px;text-align:left;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
'th{background:#f6f8fa;position:sticky;top:0;}',
'.help{font-size:11.5px;color:#57606a;line-height:1.5;}',
'.toast{background:#1f2328;color:#fff;border-radius:7px;padding:6px 9px;font-size:12.5px;}',
'.hi{position:fixed;pointer-events:none;border:2px solid #fb8500;background:rgba(251,133,0,.12);display:none;border-radius:3px;}',
'.min .tabs,.min .bd{display:none;}'
].join('\n');
root.appendChild(style);
hiBox = h('div', { cls: 'hi' }); root.appendChild(hiBox);
var panel = h('div', { cls: 'p' }); root.appendChild(panel);
var inputsTA = h('textarea', { placeholder: 'Yahan list paste karo - har line me ek entry\nGJ05AB1234\nGJ05CD5678\n...\n(Excel se 2 column copy karoge to tab se alag ho jayenge)' });
function cntText() { var a = rawInputs().length, u = parseInputs().length; return (S.uniq === false ? a + ' entries' : u + ' unique entries') + (a !== u ? ' (' + (a - u) + ' duplicate hataye)' : ''); }
inputsTA.addEventListener('input', function () { S.inputsText = inputsTA.value; save(); var c = root.querySelector('#cnt'); if (c) c.textContent = cntText(); });

function toast(m) { toastMsg = m; clearTimeout(toastT); toastT = setTimeout(function () { toastMsg = null; render(); }, 5000); render(); }
function desc(s) {
  var L = s.loc || {};
  var tgt = L.text ? '"' + L.text + '"' : L.ph ? '[' + L.ph + ']' : L.aria ? '[' + L.aria + ']' : L.name ? '[' + L.name + ']' : L.id ? '#' + L.id : (L.tag || '').toLowerCase();
  switch (s.t) {
    case 'click': return 'Click: ' + tgt;
    case 'type': return 'Likho ' + tgt;
    case 'enter': return 'Enter dabao ' + tgt;
    case 'select': return 'Chuno "' + (s.text || s.val) + '" ' + tgt;
    case 'grab': return 'Data uthao: ' + s.name + (s.sample ? '  (jaise: ' + s.sample + ')' : '');
    case 'table': return 'Poori table uthao';
    case 'wait': return 'Ruko ' + (s.sec || 2) + ' sec';
    case 'pause': return 'Ruko - main khud karunga (captcha/OTP)';
    case 'goto': return 'Page kholo';
  }
  return s.t;
}
function srcSelect(s) {
  var sel = h('select', { on: { change: function () { s.src = sel.value; save(); } } });
  [['col1', 'List se (column 1)'], ['col2', 'List se (column 2)'], ['col3', 'List se (column 3)'], ['fixed', 'Fixed: "' + (s.val || '').slice(0, 15) + '"']].forEach(function (o) {
    var op = h('option', { value: o[0], text: o[1] }); if ((s.src || 'fixed') === o[0]) op.selected = true; sel.appendChild(op);
  });
  return sel;
}
function stepRow(s, i) {
  var kids = [h('span', { cls: 'n', text: String(i + 1) }), h('span', { cls: 'd', title: desc(s), text: desc(s) })];
  if (s.t === 'type') kids.push(srcSelect(s));
  if (s.t === 'grab') kids.push(h('span', { cls: 'e', title: 'Naam badlo', text: '✎', on: { click: function () { var n = prompt('Is field ka naam (Excel column)', s.name); if (n) { s.name = n; save(); render(); } } } }));
  if (s.t === 'wait') kids.push(h('span', { cls: 'e', title: 'Seconds badlo', text: '✎', on: { click: function () { var n = parseFloat(prompt('Kitne second rukna h?', s.sec || 2)); if (n > 0) { s.sec = n; save(); render(); } } } }));
  kids.push(h('span', { cls: 'e', title: 'Upar', text: '↑', on: { click: function () { if (i > 0) { S.steps.splice(i - 1, 0, S.steps.splice(i, 1)[0]); save(); render(); } } } }));
  kids.push(h('span', { cls: 'x', title: 'Step hatao', text: '✕', on: { click: function () { S.steps.splice(i, 1); save(); render(); } } }));
  return h('div', { cls: 'st' }, kids);
}
function teachTab(bd) {
  if (!S.rec) {
    bd.appendChild(h('div', { cls: 'ban b', text: 'Jis page se kaam shuru hota h (search wala page) wahan aao, phir "Recording shuru" dabao aur ek baar poora process karke dikhao.' }));
    bd.appendChild(h('div', { cls: 'row' }, [
      h('button', { cls: 'btn rec', text: S.steps.length ? '● Recording dobara shuru (naya)' : '● Recording shuru', on: { click: async function () {
        if (S.steps.length && !confirm('Purane steps hata ke naya process sikhana h?')) return;
        S.steps = []; S.urlTpl = ''; S.useUrl = false; S.startUrl = location.href; S.rec = true; S.recTab = myTab; await save(); render();
      } } }),
      S.steps.length ? h('button', { cls: 'btn', text: '+ Aur steps jodo', on: { click: function () { S.rec = true; S.recTab = myTab; save(); render(); } } }) : null
    ]));
  } else {
    bd.appendChild(h('div', { cls: 'ban r' }, ['● RECORDING chal rahi h. Site pe normal kaam karo: search box me ek sample number likho, Search dabao. Result aaye to ',
      h('b', { text: '"+ Data uthao"' }), ' dabake jo jo cheez chahiye us pe click karo.']));
    bd.appendChild(h('div', { cls: 'row' }, [
      h('button', { cls: 'btn' + (recGrab === 'field' ? ' on' : ''), text: recGrab === 'field' ? '✓ Done (data uthana band)' : '+ Data uthao', on: { click: function () { recGrab = recGrab === 'field' ? null : 'field'; clearHi(); render(); } } }),
      h('button', { cls: 'btn' + (recGrab === 'table' ? ' on' : ''), text: '+ Poori table uthao', on: { click: function () { recGrab = recGrab === 'table' ? null : 'table'; clearHi(); render(); } } }),
      h('button', { cls: 'btn', text: '+ Ruko (sec)', on: { click: function () { pushStep({ t: 'wait', sec: 3 }); } } }),
      h('button', { cls: 'btn', text: '+ Captcha/OTP ke liye ruko', on: { click: function () { pushStep({ t: 'pause' }); } } })
    ]));
    bd.appendChild(h('div', { cls: 'row' }, [h('button', { cls: 'btn pri', text: '■ Recording band karo', on: { click: function () { S.rec = false; recGrab = null; clearHi(); detectTpl(); save(); render(); toast(S.useUrl ? 'Process save. Number URL me mila - robot har entry ka page seedha link se kholega.' : 'Process save ho gaya. Ab "2. Chalao" tab me list daalo.'); } } })]));
  }
  if (!S.rec && S.steps.length) {
    var ucb = h('input', { type: 'checkbox', on: { change: function () { S.useUrl = ucb.checked; save(); render(); } } }); ucb.checked = !!S.useUrl;
    var uin = h('input', { type: 'text', style: 'width:100%;border:1px solid #c9ced6;border-radius:6px;padding:4px;font-size:12px', value: S.urlTpl || '', placeholder: 'https://.../shipment/{1}', on: { change: function () { S.urlTpl = uin.value.trim(); if (S.urlTpl && S.urlTpl.indexOf('{1}') < 0) toast('Link me {1} hona chahiye - jahan number aata h'); save(); } } });
    bd.appendChild(h('div', { cls: 'ban b' }, [h('label', null, [ucb, ' Search ki jagah seedha link kholo (fast + pakka)']), h('div', { cls: 'help', text: 'Link me {1} = list ka number:' }), uin]));
  }
  if (S.startUrl && !S.useUrl) {
    var cb = h('input', { type: 'checkbox', on: { change: function () { S.useStart = cb.checked; save(); } } }); cb.checked = !!S.useStart;
    bd.appendChild(h('label', { cls: 'help', title: S.startUrl }, [cb, ' Har entry se pehle shuru wala page dobara kholo (recommended)']));
  }
  if (S.steps.length) {
    var box = h('div', { cls: 'steps' });
    S.steps.forEach(function (s, i) { box.appendChild(stepRow(s, i)); });
    bd.appendChild(h('b', { text: 'Sikhaye gaye steps (' + S.steps.length + '):' }));
    bd.appendChild(box);
    var hasCol = S.steps.some(function (x) { return x.t === 'type' && x.src && x.src !== 'fixed'; });
    var hasGrab = S.steps.some(function (x) { return x.t === 'grab' || x.t === 'table'; });
    if (!hasCol) bd.appendChild(h('div', { cls: 'ban y', text: 'Dhyan do: koi "Likho" step "List se" pe set nahi h - search box wale step me dropdown se "List se (column 1)" chuno.' }));
    if (!hasGrab) bd.appendChild(h('div', { cls: 'ban y', text: 'Abhi koi "Data uthao" step nahi h - result me jo chahiye wo "+ Data uthao" se chuno.' }));
  }
  bd.appendChild(h('div', { cls: 'help', text: 'Galat step record ho gaya to ✕ se hata do. Page load slow ho to "+ Ruko" jodo. Captcha wali site pe "Captcha/OTP ke liye ruko" step jodo - wahan robot rukega aur aap captcha bhar ke Continue dabaoge.' }));
}
function runTab(bd) {
  var r = S.run, inputs = parseInputs();
  if (inputsTA.value !== S.inputsText) inputsTA.value = S.inputsText || '';
  bd.appendChild(h('div', { cls: 'row' }, [h('b', { text: 'Data list:' }), h('span', { id: 'cnt', cls: 'help', text: cntText() })]));
  bd.appendChild(inputsTA);
  var uq = h('input', { type: 'checkbox', disabled: r.active ? true : false, on: { change: function () { S.uniq = uq.checked; save(); render(); } } }); uq.checked = S.uniq !== false;
  bd.appendChild(h('label', { cls: 'help' }, [uq, ' Duplicate hatao (har ID sirf ek baar search hogi)']));
  var dl = h('input', { cls: 'n', type: 'number', min: '0.5', step: '0.5', value: String(S.delay || 2), on: { change: function () { S.delay = parseFloat(dl.value) || 2; save(); } } });
  var to = h('input', { cls: 'n', type: 'number', min: '5', value: String(S.timeout || 20), on: { change: function () { S.timeout = parseFloat(to.value) || 20; save(); } } });
  bd.appendChild(h('div', { cls: 'row help' }, ['Click ke baad ruko', dl, 'sec  |  Max intezaar', to, 'sec']));
  if (r.active) {
    var P = plan(), inp = inputs[r.idx] || [];
    bd.appendChild(h('div', { cls: 'ban b', text: 'Chal raha h: entry ' + (r.idx + 1) + '/' + inputs.length + '  "' + inp.join(' | ') + '"  -  step ' + Math.min(r.step + 1, P.length) + '/' + P.length + (P[r.step] ? ' (' + desc(P[r.step]) + ')' : '') }));
    if (r.paused) {
      if (r.manual) bd.appendChild(h('div', { cls: 'ban y', text: 'Robot ruka h - captcha/OTP jo bhi h aap bharo (Submit mat dabana agar wo agla step h), phir Continue dabao.' }));
      bd.appendChild(h('div', { cls: 'row' }, [
        h('button', { cls: 'btn go', text: '▶ Continue', on: { click: async function () { S.run.paused = false; S.run.manual = false; S.run.tab = myTab; await save(); runLoop(); } } }),
        h('button', { cls: 'btn red', text: '■ Band karo', on: { click: function () { S.run.active = false; S.run.paused = false; save(); render(); } } })
      ]));
    } else {
      bd.appendChild(h('div', { cls: 'row' }, [
        h('button', { cls: 'btn', text: '⏸ Roko', on: { click: function () { S.run.paused = true; S.run.manual = false; save(); render(); } } }),
        h('button', { cls: 'btn red', text: '■ Band karo', on: { click: function () { S.run.active = false; save(); render(); } } })
      ]));
    }
  } else {
    var canResume = r.idx > 0 && r.idx < inputs.length;
    bd.appendChild(h('div', { cls: 'row' }, [
      h('button', { cls: 'btn go', text: canResume ? '▶ Shuru se chalao' : '▶ Chalao', on: { click: function () { start(0); } } }),
      canResume ? h('button', { cls: 'btn pri', text: '▶ Entry ' + (r.idx + 1) + ' se aage chalao', on: { click: function () { start(r.idx); } } }) : null
    ]));
    bd.appendChild(h('div', { cls: 'help', text: 'Tip: pehle 2-3 entries daal ke test karo. Sab sahi aaye to poori list daalo. Chalte waqt is tab ko band mat karna, aur mouse se page pe kuch mat karna.' }));
  }
}
async function start(from) {
  if (!S.steps.length) { toast('Pehle "1. Sikhao" me process record karo'); return; }
  if (!parseInputs().length) { toast('List khali h - entries paste karo'); return; }
  if (from === 0 && S.results.length && confirm('Purane results bhi rakhne h? (OK = rakho, Cancel = mita do)') === false) S.results = [];
  S.rec = false; recGrab = null;
  S.run = { active: true, paused: false, manual: false, tab: myTab, idx: from, step: 0, cur: {}, rows: null, err: '' };
  await save(); runLoop();
}
function columns() {
  var maxIn = 1; S.results.forEach(function (r) { maxIn = Math.max(maxIn, (r.in || []).length); });
  var grabs = S.steps.filter(function (s) { return s.t === 'grab'; });
  var hasT = S.results.some(function (r) { return r.t; }), maxT = 0;
  S.results.forEach(function (r) { if (r.t) maxT = Math.max(maxT, r.t.length); });
  var hdr = [];
  for (var i = 0; i < maxIn; i++) hdr.push(maxIn === 1 ? 'Input' : 'Input ' + (i + 1));
  grabs.forEach(function (g) { hdr.push(g.name); });
  if (hasT) for (var j = 0; j < maxT; j++) hdr.push(S.tableHdr[j] || 'Col ' + (j + 1));
  hdr.push('Robot Status');
  var rows = S.results.map(function (r) {
    var o = []; for (var i = 0; i < maxIn; i++) o.push((r.in || [])[i] || '');
    grabs.forEach(function (g) { o.push((r.v || {})[g.id] || ''); });
    if (hasT) for (var j = 0; j < maxT; j++) o.push(r.t ? (r.t[j] || '') : '');
    o.push(r.err ? 'ERROR: ' + r.err : 'OK');
    return o;
  });
  return { hdr: hdr, rows: rows };
}
function download() {
  if (!S.results.length) { toast('Abhi koi result nahi'); return; }
  var c = columns(), esc = function (v) { v = String(v == null ? '' : v); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  var csv = [c.hdr].concat(c.rows).map(function (r) { return r.map(esc).join(','); }).join('\r\n');
  var u = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
  var d = new Date(), p = function (x) { return (x < 10 ? '0' : '') + x; };
  var a = document.createElement('a'); a.href = u; a.download = 'robot_data_' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + '.csv';
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 5000);
  toast('CSV download ho gayi - Excel me khul jayegi');
}
function copyAll() {
  if (!S.results.length) { toast('Abhi koi result nahi'); return; }
  var c = columns(), f = function (v) { return String(v == null ? '' : v).replace(/[\t\r\n]+/g, ' '); };
  var txt = [c.hdr].concat(c.rows).map(function (r) { return r.map(f).join('\t'); }).join('\n');
  navigator.clipboard.writeText(txt).then(function () { toast('Copy ho gaya - Excel me Ctrl+V'); }, function () {
    var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Copy ho gaya - Excel me Ctrl+V'); } catch (e) { toast('Copy nahi hua - Download use karo'); } ta.remove();
  });
}
function resultTab(bd) {
  var c = columns(), errs = S.results.filter(function (r) { return r.err; }).length;
  bd.appendChild(h('div', { cls: 'ban b', text: 'Total rows: ' + S.results.length + (errs ? '   |   Error wali: ' + errs : '') }));
  if (S.results.length) {
    var tb = h('table'), tr = h('tr');
    c.hdr.forEach(function (x) { tr.appendChild(h('th', { text: x })); });
    tb.appendChild(h('thead', null, [tr]));
    var body = h('tbody');
    c.rows.slice(-10).forEach(function (r) { var t = h('tr'); r.forEach(function (v) { t.appendChild(h('td', { title: v, text: v })); }); body.appendChild(t); });
    tb.appendChild(body); bd.appendChild(h('div', { cls: 'tw' }, [tb]));
    if (S.results.length > 10) bd.appendChild(h('div', { cls: 'help', text: 'Preview me aakhri 10 rows. Download me sab aayengi.' }));
  }
  bd.appendChild(h('div', { cls: 'row' }, [
    h('button', { cls: 'btn pri', text: '⬇ Excel/CSV download', on: { click: download } }),
    h('button', { cls: 'btn', text: 'Copy (Excel me paste)', on: { click: copyAll } }),
    h('button', { cls: 'btn red', text: 'Results mitao', on: { click: function () { if (confirm('Saare results mita dein?')) { S.results = []; save(); render(); } } } })
  ]));
  bd.appendChild(h('div', { cls: 'row' }, [
    h('button', { cls: 'btn red', text: 'Sab kuch mitao (process + list + results)', on: { click: async function () { if (confirm('Process, list aur results sab mita dein? (dost ke laptop pe kuch na rahe)')) { var o = S.openTab; S = fresh(); S.openTab = o; inputsTA.value = ''; await save(); render(); } } } })
  ]));
}
function render() {
  if (!S) return;
  var show = S.openTab === myTab && myTab != null;
  if (!show) { if (host.isConnected) host.remove(); return; }
  if (!host.isConnected) document.documentElement.appendChild(host);
  panel.textContent = '';
  panel.className = 'p' + (minimized ? ' min' : '');
  var hd = h('div', { cls: 'hd' }, [h('b', { text: 'Process Robot' + (S.rec ? '  ● REC' : '') + (S.run.active ? '  ▶ RUN' : '') }),
    h('button', { title: 'Chhota/Bada', text: minimized ? '+' : '_', on: { click: function () { minimized = !minimized; render(); } } }),
    h('button', { title: 'Panel band (icon se wapas khulega)', text: 'x', on: { click: function () { S.openTab = null; save(); render(); } } })]);
  drag(hd); panel.appendChild(hd);
  var tabs = h('div', { cls: 'tabs' });
  [['teach', '1. Sikhao'], ['run', '2. Chalao'], ['result', '3. Result (' + S.results.length + ')']].forEach(function (t) {
    tabs.appendChild(h('button', { cls: S.tab === t[0] ? 'on' : '', text: t[1], on: { click: function () { S.tab = t[0]; save(); render(); } } }));
  });
  panel.appendChild(tabs);
  var bd = h('div', { cls: 'bd' }); panel.appendChild(bd);
  if (S.tab === 'teach') teachTab(bd); else if (S.tab === 'run') runTab(bd); else resultTab(bd);
  if (toastMsg) bd.appendChild(h('div', { cls: 'toast', text: toastMsg }));
}
function drag(hd) {
  hd.addEventListener('mousedown', function (e) {
    if (e.target.tagName === 'BUTTON') return;
    var r = panel.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
    function mv(ev) { panel.style.left = Math.max(0, ev.clientX - dx) + 'px'; panel.style.top = Math.max(0, ev.clientY - dy) + 'px'; panel.style.right = 'auto'; panel.style.bottom = 'auto'; }
    function up() { document.removeEventListener('mousemove', mv, true); document.removeEventListener('mouseup', up, true); }
    document.addEventListener('mousemove', mv, true); document.addEventListener('mouseup', up, true); e.preventDefault();
  });
}

/* ================= init ================= */
['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'dblclick', 'submit'].forEach(function (t) { document.addEventListener(t, blockCap, true); });
document.addEventListener('click', onClickCap, true);
document.addEventListener('change', onChangeCap, true);
document.addEventListener('keydown', onKeyCap, true);
document.addEventListener('mousemove', onMove, true);

chrome.runtime.onMessage.addListener(function (m) {
  if (m && m.q === 'toggle') {
    load().then(function () { S.openTab = S.openTab === myTab ? null : myTab; return save(); }).then(render);
  }
});
chrome.storage.onChanged.addListener(function (ch) {
  if (!ch[KEY] || !S) return;
  var n = ch[KEY].newValue; if (!n) return;
  if (n.openTab !== S.openTab) { S.openTab = n.openTab; render(); }
});

chrome.runtime.sendMessage({ q: 'tabId' }, function (id) {
  myTab = id;
  load().then(async function () {
    render();
    if (S.run.active && !S.run.paused && S.run.tab === myTab) { await sleep(1000); runLoop(); }
  });
});
})();
